/** 
╔══╗ ╔═╗╔═╗╔╗╔╗╔╗    ╔═╗╔═╗╔═══╗
║╔╗║ ║║╚╝║║║║║║║║    ║║╚╝║║╚╗╔╗║
║╚╝╚╗║╔╗╔╗║║║║║║║    ║╔╗╔╗║ ║║║║
║╔═╗║║║║║║║║╚╝╚╝║    ║║║║║║ ║║║║
║╚═╝║║║║║║║╚╗╔╗╔╝    ║║║║║║╔╝╚╝║
╚═══╝╚╝╚╝╚╝ ╚╝╚╝     ╚╝╚╝╚╝╚═══╝
                                
                                
 ___  __  __ __      __       __  __  ___  
| _ )|  \/  |\ \    / /      |  \/  ||   \ 
| _ \| |\/| | \ \/\/ /       | |\/| || |) |
|___/|_|  |_|  \_/\_/        |_|  |_||___/ 

Made by Ibrahim Adams







   
   
   
   
   
   
   
   
   
   






























**/
function _0x11f3(){const _0x70517b=['thumbnail','ytdl-core','6DERfpV','3912020Ouvwun','12838378JJhScC','videoId','1919958dZtqWP','4344028OqrUkK','downloadFromInfo','892765NqGbJI','chooseFormat','yt-search','12037095TIFpBi','exports','videos','5alpetW','2BMRwif','error','timestamp','title','formats','7884296hAGVBC','getInfo'];_0x11f3=function(){return _0x70517b;};return _0x11f3();}const _0x545687=_0x3a6d;(function(_0x31f7a9,_0x4f0a8e){const _0xfec102=_0x3a6d,_0x29e028=_0x31f7a9();while(!![]){try{const _0x2951b4=parseInt(_0xfec102(0xa0))/0x1+-parseInt(_0xfec102(0xa7))/0x2*(parseInt(_0xfec102(0x9d))/0x3)+-parseInt(_0xfec102(0x9e))/0x4*(parseInt(_0xfec102(0xa6))/0x5)+-parseInt(_0xfec102(0x99))/0x6*(-parseInt(_0xfec102(0x9b))/0x7)+-parseInt(_0xfec102(0xac))/0x8+parseInt(_0xfec102(0xa3))/0x9+-parseInt(_0xfec102(0x9a))/0xa;if(_0x2951b4===_0x4f0a8e)break;else _0x29e028['push'](_0x29e028['shift']());}catch(_0x1feaf2){_0x29e028['push'](_0x29e028['shift']());}}}(_0x11f3,0xeac06));function _0x3a6d(_0x3c720f,_0x4984ec){const _0x11f34f=_0x11f3();return _0x3a6d=function(_0x3a6db1,_0x5bb4b0){_0x3a6db1=_0x3a6db1-0x98;let _0x1903d3=_0x11f34f[_0x3a6db1];return _0x1903d3;},_0x3a6d(_0x3c720f,_0x4984ec);}const yts=require(_0x545687(0xa2)),ytdl=require(_0x545687(0x98)),fs=require('fs');async function getytlink(_0x4f2762){const _0x47bf3f=_0x545687;try{const _0x19fe39=await yts(_0x4f2762),_0x12e66d=_0x19fe39[_0x47bf3f(0xa5)],_0x3ed7ba=_0x12e66d[0x0];return{'lien':_0x3ed7ba['url'],'affiche':_0x3ed7ba[_0x47bf3f(0xae)],'titre':_0x3ed7ba[_0x47bf3f(0xaa)],'duree':_0x3ed7ba[_0x47bf3f(0xa9)],'id':_0x3ed7ba[_0x47bf3f(0x9c)]};}catch(_0x1b4afd){return console[_0x47bf3f(0xa8)]('Erreur\x20lors\x20de\x20la\x20recherche\x20YouTube\x20:',_0x1b4afd),null;}}module['exports']=getytlink;async function ytdwn(_0x541951){const _0x241eab=_0x545687,_0x1625c5=await ytdl[_0x241eab(0xad)](_0x541951),_0x47c04e=ytdl[_0x241eab(0xa1)](_0x1625c5[_0x241eab(0xab)],{'quality':'18'}),_0x3cd1b7=ytdl[_0x241eab(0x9f)](_0x1625c5,_0x47c04e);return _0x3cd1b7;}module[_0x545687(0xa4)]=ytdwn;
